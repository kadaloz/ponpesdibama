// resources/views/components/form/section.blade.php
@props(['title'])

<h3 class="text-xl font-bold text-teal-700 mb-4 mt-6 border-b pb-2">{{ $title }}</h3>
