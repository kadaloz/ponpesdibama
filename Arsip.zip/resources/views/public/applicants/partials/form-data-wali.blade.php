<h3 class="text-xl font-bold text-teal-700 mb-4 border-b pb-2 pt-6">Data Orang Tua / Wali</h3>
<div class="space-y-4">
    <x-input label="Nama Ayah / Wali" name="parent_name" required />
    <x-input label="Nomor HP / WhatsApp Orang Tua / Wali" name="parent_phone" required />
    <x-input label="Email Orang Tua / Wali (Opsional)" name="parent_email" type="email" />
    <x-input label="Pekerjaan Orang Tua / Wali (Opsional)" name="parent_occupation" />
</div>