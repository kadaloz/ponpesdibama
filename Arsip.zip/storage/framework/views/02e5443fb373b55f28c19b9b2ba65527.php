<svg <?php echo e($attributes->merge(['class' => 'w-6 h-6'])); ?> fill="currentColor" viewBox="0 0 24 24">
    <path d="M22.675 0h-21.35C.6 0 0 .6 0 1.337v21.326C0 23.4.6 24 
        1.325 24H12.82v-9.294H9.692V11.29h3.127V8.413c0-3.1 
        1.893-4.788 4.659-4.788 1.325 0 2.463.099 
        2.794.143v3.24h-1.918c-1.504 0-1.796.715-1.796 
        1.764v2.313h3.587l-.467 3.416h-3.12V24h6.116C23.4 
        24 24 23.4 24 22.663V1.337C24 .6 23.4 0 22.675 0z"/>
</svg>
<?php /**PATH /Users/husnulfuadifebriansyah/Documents/project/ponpesdibama/resources/views/components/icons/facebook.blade.php ENDPATH**/ ?>