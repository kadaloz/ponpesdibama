<?php $__env->startSection('title', 'Manajemen Halaqoh'); ?>
<?php $__env->startSection('header_admin', 'Manajemen Halaqoh'); ?>

<?php $__env->startSection('admin_content'); ?>
<div class="bg-white shadow-sm rounded-lg p-6">
    
    <div class="flex flex-col md:flex-row md:justify-between md:items-center gap-4 mb-6">
        <h3 class="text-2xl md:text-3xl font-bold text-teal-700">Daftar Halaqoh</h3>
        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create halaqohs')): ?>
            <a href="<?php echo e(route('admin.halaqohs.create')); ?>"
               class="inline-flex items-center px-5 py-2.5 bg-teal-600 text-white text-sm rounded-md hover:bg-teal-700 transition shadow-md">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                </svg>
                Tambah Halaqoh
            </a>
        <?php endif; ?>
    </div>

    
    <div class="mb-6">
        <form method="GET" action="<?php echo e(route('admin.halaqohs.index')); ?>" class="flex flex-wrap items-center gap-3">
            <input type="text" name="search" placeholder="Cari nama halaqoh / pengajar..." value="<?php echo e(request('search')); ?>"
                class="text-sm px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500">
            
            <select name="status" class="text-sm px-6 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500">
                <option value="">-- Semua Status --</option>
                <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Aktif</option>
                <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>Tidak Aktif</option>
                <option value="completed" <?php echo e(request('status') == 'completed' ? 'selected' : ''); ?>>Selesai</option>
            </select>

            <button type="submit"
                class="inline-flex items-center px-4 py-2 bg-teal-600 text-white text-sm rounded-md hover:bg-teal-700 transition">
                Filter
            </button>

            <?php if(request()->has('search') || request()->has('status')): ?>
                <a href="<?php echo e(route('admin.halaqohs.index')); ?>" class="text-sm text-gray-600 hover:underline ml-2">
                    Reset
                </a>
            <?php endif; ?>
        </form>
    </div>

    
    <?php if(session('success')): ?>
        <div class="mb-4 p-3 bg-green-50 border border-green-200 text-green-700 rounded shadow-sm text-sm">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <?php if($allHalaqohs->isEmpty()): ?>
        <p class="text-center text-gray-600 bg-gray-50 py-8 rounded border border-dashed">
            Belum ada halaqoh terdaftar.
        </p>
    <?php else: ?>
        <div class="overflow-x-auto rounded shadow">
            <table class="min-w-full bg-white border border-gray-200">
                <thead class="bg-gray-100 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    <tr>
                        <th class="px-4 py-3 text-left">Nama</th>
                        <th class="px-4 py-3 text-left">Pengajar</th>
                        <th class="px-4 py-3 text-left">Santri</th>
                        <th class="px-4 py-3 text-left">Status</th>
                        <th class="px-4 py-3 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="text-sm text-gray-700">
                    <?php $__currentLoopData = $allHalaqohs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $halaqoh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-t hover:bg-gray-50 transition">
                            <td class="px-4 py-3"><?php echo e($halaqoh->name); ?></td>
                            <td class="px-4 py-3"><?php echo e($halaqoh->teacher->full_name ?? '-'); ?></td>
                            <td class="px-4 py-3"><?php echo e($halaqoh->students->count()); ?></td>
                            <td class="px-4 py-3">
                                <span class="px-2 py-1 rounded-full text-xs font-medium
                                    <?php echo e($halaqoh->status == 'active' ? 'bg-green-100 text-green-700' :
                                       ($halaqoh->status == 'inactive' ? 'bg-yellow-100 text-yellow-700' :
                                       ($halaqoh->status == 'completed' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'))); ?>">
                                    <?php echo e(ucfirst($halaqoh->status)); ?>

                                </span>
                            </td>
                            <td class="px-4 py-3 text-center space-x-2">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view halaqohs')): ?>
                                    <a href="<?php echo e(route('admin.halaqohs.show', $halaqoh->id)); ?>"
                                       class="inline-flex items-center px-3 py-1 text-sm bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition">
                                        <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                  d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                  d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7
                                                  -1.274 4.057-5.064 7-9.542 7-4.478 0-8.268-2.943-9.542-7z" />
                                        </svg>
                                        Lihat
                                    </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit halaqohs')): ?>
                                    <a href="<?php echo e(route('admin.halaqohs.edit', $halaqoh->id)); ?>"
                                       class="inline-flex items-center px-3 py-1 text-sm bg-indigo-600 text-white rounded hover:bg-indigo-700 transition">
                                        <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                  d="M15.232 5.232l3.536 3.536m-2.036-5.036
                                                  a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                                        </svg>
                                        Edit
                                    </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete halaqohs')): ?>
                                    <form action="<?php echo e(route('admin.halaqohs.destroy', $halaqoh->id)); ?>" method="POST"
                                          class="inline" onsubmit="return confirm('Hapus halaqoh ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                                class="inline-flex items-center px-3 py-1 text-sm bg-red-600 text-white rounded hover:bg-red-700 transition">
                                            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                      d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862
                                                      a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6" />
                                            </svg>
                                            Hapus
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        
        <div class="mt-6">
            <?php echo e($allHalaqohs->appends(request()->query())->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/husnulfuadifebriansyah/Documents/project/ponpesdibama/resources/views/admin/halaqohs/index.blade.php ENDPATH**/ ?>