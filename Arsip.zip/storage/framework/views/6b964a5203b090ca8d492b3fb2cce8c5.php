<svg <?php echo e($attributes->merge(['class' => 'w-6 h-6'])); ?> fill="currentColor" viewBox="0 0 24 24">
    <path d="M23.498 6.186a2.972 2.972 0 00-2.096-2.107C19.566 
        3.5 12 3.5 12 3.5s-7.566 0-9.402.579a2.972 2.972 
        0 00-2.096 2.107A31.234 31.234 0 000 12a31.234 
        31.234 0 00.502 5.814 2.972 2.972 0 002.096 
        2.107C4.434 20.5 12 20.5 12 20.5s7.566 
        0 9.402-.579a2.972 2.972 0 002.096-2.107A31.234 
        31.234 0 0024 12a31.234 31.234 0 00-.502-5.814zM9.75 
        15.02v-6.04l6 3.02-6 3.02z"/>
</svg>
<?php /**PATH /Users/husnulfuadifebriansyah/Documents/project/ponpesdibama/resources/views/components/icons/youtube.blade.php ENDPATH**/ ?>