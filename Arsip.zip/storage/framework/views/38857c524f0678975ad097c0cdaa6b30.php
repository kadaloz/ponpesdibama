<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['program']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['program']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="bg-white p-8 rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 border border-teal-100 h-full flex flex-col justify-between">
    <div>
        <h3 class="text-xl md:text-2xl font-bold text-teal-700 mb-4 leading-snug"><?php echo e($program->name); ?></h3>
        <p class="text-gray-600 text-base leading-relaxed mb-4">
            <?php echo e(Str::limit(strip_tags($program->description), 150)); ?>

        </p>
        <p class="text-sm text-gray-500 italic mb-6">Durasi: <?php echo e($program->duration ?? '-'); ?></p>
    </div>

    <a href="<?php echo e(route('programs.show', $program->slug)); ?>"
       class="inline-flex items-center text-teal-600 hover:text-teal-800 font-medium transition group">
        Detail Program
        <svg class="w-4 h-4 ml-2 transition-transform duration-200 transform group-hover:translate-x-1"
             fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
        </svg>
    </a>
</div>
<?php /**PATH /Users/husnulfuadifebriansyah/Documents/project/ponpesdibama/resources/views/components/program/card.blade.php ENDPATH**/ ?>