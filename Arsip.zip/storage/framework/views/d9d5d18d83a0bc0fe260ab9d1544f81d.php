<?php $__env->startSection('title', 'Detail Halaqoh'); ?>
<?php $__env->startSection('header_admin', 'Detail Halaqoh'); ?>

<?php $__env->startSection('admin_content'); ?>
<div class="bg-white shadow-sm rounded-lg p-6">
    
    <h2 class="text-2xl font-bold text-teal-700 mb-4">Informasi Umum</h2>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
        <div>
            <span class="font-medium text-gray-700">Nama Halaqoh:</span>
            <p class="text-gray-800"><?php echo e($halaqoh->name); ?></p>
        </div>
        <div>
            <span class="font-medium text-gray-700">Pengajar:</span>
            <p class="text-gray-800"><?php echo e($halaqoh->teacher->full_name ?? '-'); ?></p>
        </div>
        <div>
            <span class="font-medium text-gray-700">Tanggal Mulai:</span>
            <p class="text-gray-800"><?php echo e($halaqoh->start_date ?? '-'); ?></p>
        </div>
        <div>
            <span class="font-medium text-gray-700">Tanggal Selesai:</span>
            <p class="text-gray-800"><?php echo e($halaqoh->end_date ?? '-'); ?></p>
        </div>
        <div>
            <span class="font-medium text-gray-700">Status:</span>
            <p class="text-gray-800 capitalize"><?php echo e($halaqoh->status); ?></p>
        </div>
        <div>
            <span class="font-medium text-gray-700">Batas Santri:</span>
            <p class="text-gray-800"><?php echo e($halaqoh->student_limit ?? '-'); ?></p>
        </div>
    </div>

    
    <?php if($halaqoh->description): ?>
        <div class="mt-4">
            <span class="font-medium text-gray-700">Deskripsi:</span>
            <p class="text-gray-800"><?php echo e($halaqoh->description); ?></p>
        </div>
    <?php endif; ?>

    
    <h3 class="text-xl font-semibold text-teal-700 mt-8 mb-3 border-b pb-1">Daftar Santri</h3>
    <?php if($halaqoh->students->isEmpty()): ?>
        <p class="text-gray-600 text-sm">Belum ada santri yang terdaftar.</p>
    <?php else: ?>
        <ul class="list-disc list-inside text-sm text-gray-800 space-y-1">
            <?php $__currentLoopData = $halaqoh->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($student->name); ?> (NIS: <?php echo e($student->nis); ?>)</li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

    
    <h3 class="text-xl font-semibold text-teal-700 mt-8 mb-3 border-b pb-1">Jadwal Halaqoh</h3>
    <?php if($halaqoh->schedules->isEmpty()): ?>
        <p class="text-gray-600 text-sm">Belum ada jadwal.</p>
    <?php else: ?>
        <table class="w-full mt-2 text-sm border border-gray-200 rounded-lg overflow-hidden">
            <thead class="bg-teal-600 text-white">
                <tr>
                    <th class="px-4 py-2 text-left">Hari</th>
                    <th class="px-4 py-2 text-left">Jam</th>
                    <th class="px-4 py-2 text-left">Lokasi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $halaqoh->schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-t">
                        <td class="px-4 py-2"><?php echo e($schedule->day_of_week); ?></td>
                        <td class="px-4 py-2"><?php echo e($schedule->start_time); ?> - <?php echo e($schedule->end_time); ?></td>
                        <td class="px-4 py-2"><?php echo e($schedule->location ?? '-'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>

    
    <h3 class="text-xl font-semibold text-teal-700 mt-10 mb-3 border-b pb-1">Riwayat Perubahan Jadwal</h3>

    
    <form method="GET" action="<?php echo e(route('admin.halaqohs.show', $halaqoh->id)); ?>" class="flex flex-wrap items-center gap-2 mb-4">
        <input type="date" name="start_date" value="<?php echo e(request('start_date')); ?>" class="border rounded px-2 py-1 text-sm">
        <input type="date" name="end_date" value="<?php echo e(request('end_date')); ?>" class="border rounded px-2 py-1 text-sm">
        <button type="submit" class="bg-teal-600 text-white text-sm px-3 py-1 rounded hover:bg-teal-700">Filter</button>
        <a href="<?php echo e(route('admin.halaqohs.show', ['halaqoh' => $halaqoh->id, 'show' => 'all'])); ?>" class="bg-gray-600 text-white text-sm px-3 py-1 rounded hover:bg-gray-700">Tampilkan Semua</a>
    </form>

    <?php if($logs->isEmpty()): ?>
        <p class="text-gray-600 text-sm">Belum ada riwayat perubahan jadwal.</p>
    <?php else: ?>
        <div class="overflow-x-auto mt-2">
            <table class="w-full text-sm border border-gray-200 rounded-lg shadow-sm">
                <thead class="bg-gray-100 text-gray-800">
                    <tr>
                        <th class="px-4 py-2 text-left">Tanggal</th>
                        <th class="px-4 py-2 text-left">Aksi</th>
                        <th class="px-4 py-2 text-left">Hari</th>
                        <th class="px-4 py-2 text-left">Jam</th>
                        <th class="px-4 py-2 text-left">Lokasi</th>
                        <th class="px-4 py-2 text-left">User</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $data = $log->data_after ?? $log->data_before ?? [];
                        ?>
                        <tr class="border-t">
                            <td class="px-4 py-2"><?php echo e(\Carbon\Carbon::parse($log->created_at)->format('d/m/Y H:i')); ?></td>
                            <td class="px-4 py-2 capitalize"><?php echo e($log->action); ?></td>
                            <td class="px-4 py-2"><?php echo e($data['day_of_week'] ?? '-'); ?></td>
                            <td class="px-4 py-2">
                                <?php echo e($data['start_time'] ?? '-'); ?> - <?php echo e($data['end_time'] ?? '-'); ?>

                            </td>
                            <td class="px-4 py-2"><?php echo e($data['location'] ?? '-'); ?></td>
                            <td class="px-4 py-2"><?php echo e(optional($log->user)->name ?? '-'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            
            <?php if(method_exists($logs, 'links')): ?>
                <div class="mt-4">
                    <?php echo e($logs->appends(request()->query())->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    
    <div class="mt-8">
        <a href="<?php echo e(route('admin.halaqohs.index')); ?>"
            class="inline-block px-4 py-2 bg-gray-100 hover:bg-gray-200 text-sm text-gray-800 rounded-md border border-gray-300">
            ← Kembali ke Daftar Halaqoh
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/husnulfuadifebriansyah/Documents/project/ponpesdibama/resources/views/admin/halaqohs/show.blade.php ENDPATH**/ ?>