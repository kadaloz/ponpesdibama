<?php $__env->startSection('title', 'Detail Pengajar: ' . $teacher->full_name); ?>
<?php $__env->startSection('header_admin', 'Detail Data Pengajar'); ?>

<?php $__env->startSection('admin_content'); ?>
<div class="bg-white shadow sm:rounded-lg p-8">
    <h2 class="text-2xl font-bold text-teal-700 mb-6 border-b pb-3">Profil Lengkap Pengajar</h2>

    
    <div class="bg-teal-50 border border-teal-200 rounded-lg p-6 mb-8">
        <h3 class="text-lg font-semibold text-teal-800 mb-4">Informasi Umum</h3>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 text-gray-700">
            <div>
                <p class="text-sm font-medium text-gray-600">NIP</p>
                <p class="text-lg font-semibold"><?php echo e($teacher->nip ?? '-'); ?></p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-600">Nama Lengkap</p>
                <p class="text-lg font-semibold"><?php echo e($teacher->full_name); ?></p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-600">Spesialisasi</p>
                <p class="text-base"><?php echo e($teacher->specialization ?? '-'); ?></p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-600">Status</p>
                <span class="inline-block px-3 py-1 rounded-full text-sm font-semibold <?php echo e($teacher->status == 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                    <?php echo e(ucfirst($teacher->status)); ?>

                </span>
            </div>
            <div class="sm:col-span-2">
                <p class="text-sm font-medium text-gray-600">Akun Pengguna</p>
                <?php if($teacher->user): ?>
                    <p class="text-base"><?php echo e($teacher->user->name); ?> (<?php echo e($teacher->user->email); ?>)</p>
                <?php else: ?>
                    <p class="text-base italic text-gray-500">Belum terhubung dengan akun pengguna.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <div class="bg-gray-50 border border-gray-200 rounded-lg p-6">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Informasi Pribadi</h3>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 text-gray-700">
            <div>
                <p class="text-sm font-medium text-gray-600">Jenis Kelamin</p>
                <p class="text-base"><?php echo e($teacher->gender ?? '-'); ?></p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-600">Tempat, Tanggal Lahir</p>
                <p class="text-base">
                    <?php echo e($teacher->place_of_birth ?? '-'); ?>,
                    <?php echo e($teacher->date_of_birth ? \Carbon\Carbon::parse($teacher->date_of_birth)->translatedFormat('d F Y') : '-'); ?>

                </p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-600">No. Telepon</p>
                <p class="text-base"><?php echo e($teacher->phone_number ?? '-'); ?></p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-600">Tanggal Bergabung</p>
                <p class="text-base">
                    <?php echo e($teacher->join_date ? \Carbon\Carbon::parse($teacher->join_date)->translatedFormat('d F Y') : '-'); ?>

                </p>
            </div>
        </div>
    </div>

    
    <div class="mt-8 flex justify-end gap-3 border-t pt-6">
        <a href="<?php echo e(route('admin.teachers.index')); ?>"
           class="inline-flex items-center px-5 py-2 rounded-full bg-gray-200 hover:bg-gray-300 text-sm font-medium text-gray-700 transition">
            <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-arrow-left'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
            Kembali
        </a>
        <a href="<?php echo e(route('admin.teachers.edit', $teacher->id)); ?>"
           class="inline-flex items-center px-5 py-2 rounded-full bg-indigo-600 hover:bg-indigo-700 text-sm font-medium text-white transition">
           <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-pencil'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 mr-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
            Edit
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/husnulfuadifebriansyah/Documents/project/ponpesdibama/resources/views/admin/teachers/show.blade.php ENDPATH**/ ?>