<?php $__env->startSection('title', 'Edit Halaqoh: ' . $halaqoh->name); ?>

<?php $__env->startSection('header_admin', 'Edit Halaqoh'); ?>

<?php $__env->startSection('admin_content'); ?>
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 text-gray-900">
            <form action="<?php echo e(route('admin.halaqohs.update', $halaqoh->id)); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <h3 class="text-xl font-bold text-teal-700 mb-4 border-b pb-2">Informasi Halaqoh</h3>

                <div>
                    <label for="name" class="block text-sm font-medium text-gray-700">Nama Halaqoh</label>
                    <input type="text" name="name" id="name" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500" value="<?php echo e(old('name', $halaqoh->name)); ?>" required>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="description" class="block text-sm font-medium text-gray-700">Deskripsi (Opsional)</label>
                    <textarea name="description" id="description" rows="3" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500"><?php echo e(old('description', $halaqoh->description)); ?></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="teacher_id" class="block text-sm font-medium text-gray-700">Pengajar Utama</label>
                    <select name="teacher_id" id="teacher_id" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500">
                        <option value="">Pilih Pengajar</option>
                        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($teacher->id); ?>" <?php echo e(old('teacher_id', $halaqoh->teacher_id) == $teacher->id ? 'selected' : ''); ?>><?php echo e($teacher->full_name); ?> (<?php echo e($teacher->specialization ?? 'Umum'); ?>)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['teacher_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="start_date" class="block text-sm font-medium text-gray-700">Tanggal Mulai (Opsional)</label>
                        <input type="date" name="start_date" id="start_date" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500" value="<?php echo e(old('start_date', $halaqoh->start_date?->format('Y-m-d'))); ?>">
                        <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label for="end_date" class="block text-sm font-medium text-gray-700">Tanggal Selesai (Opsional)</label>
                        <input type="date" name="end_date" id="end_date" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500" value="<?php echo e(old('end_date', $halaqoh->end_date?->format('Y-m-d'))); ?>">
                        <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div>
                    <label for="status" class="block text-sm font-medium text-gray-700">Status Halaqoh</label>
                    <select name="status" id="status" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500" required>
                        <option value="active" <?php echo e(old('status', $halaqoh->status) == 'active' ? 'selected' : ''); ?>>Aktif</option>
                        <option value="inactive" <?php echo e(old('status', $halaqoh->status) == 'inactive' ? 'selected' : ''); ?>>Tidak Aktif</option>
                        <option value="completed" <?php echo e(old('status', $halaqoh->status) == 'completed' ? 'selected' : ''); ?>>Selesai</option>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="student_limit" class="block text-sm font-medium text-gray-700">Batas Jumlah Santri (0 untuk tanpa batas)</label>
                    <input type="number" name="student_limit" id="student_limit" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500" value="<?php echo e(old('student_limit', $halaqoh->student_limit)); ?>" min="0">
                    <?php $__errorArgs = ['student_limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <h3 class="text-xl font-bold text-teal-700 mb-4 border-b pb-2 pt-6">Santri dalam Halaqoh</h3>
                <p class="text-sm text-gray-600 mb-4">Pilih santri yang akan tergabung dalam halaqoh ini. Santri yang sudah ada akan tetap terpilih.</p>
                
                
                <div>
                    <label for="selected_students" class="block text-sm font-medium text-gray-700">Pilih Santri</label>
                    <select name="selected_students[]" id="selected_students" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500 h-48" multiple>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($student->id); ?>" data-data='{"type": "<?php echo e($student->type ?? 'N/A'); ?>"}' <?php echo e((is_array(old('selected_students', $currentStudents)) && in_array($student->id, old('selected_students', $currentStudents))) ? 'selected' : ''); ?>><?php echo e($student->name); ?> (NIS: <?php echo e($student->nis ?? '-'); ?>) - Tipe: <?php echo e($student->type ?? 'N/A'); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['selected_students'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php $__errorArgs = ['selected_students.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <h3 class="text-xl font-bold text-teal-700 mb-4 border-b pb-2 pt-6">Jadwal Halaqoh</h3>
                <p class="text-sm text-gray-600 mb-4">Kelola jadwal pertemuan untuk halaqoh ini.</p>
                <div id="schedules-container" class="space-y-4">
                    <?php $__currentLoopData = $halaqoh->schedules->sortBy('day_of_week'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex flex-col md:flex-row items-end space-y-2 md:space-y-0 md:space-x-2 schedule-item existing-schedule-item" id="schedule-<?php echo e($schedule->id); ?>">
                            <input type="hidden" name="schedules[<?php echo e($index); ?>][id]" value="<?php echo e($schedule->id); ?>">
                            <div class="w-full md:w-1/4">
                                <label class="block text-sm font-medium text-gray-700">Hari</label>
                                <select name="schedules[<?php echo e($index); ?>][day_of_week]" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500">
                                    <option value="">Pilih Hari</option>
                                    <?php $__currentLoopData = $daysOfWeek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($day); ?>" <?php echo e(old('schedules.' . $index . '.day_of_week', $schedule->day_of_week) == $day ? 'selected' : ''); ?>><?php echo e($day); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['schedules.' . $index . '.day_of_week'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="w-full md:w-1/4">
                                <label class="block text-sm font-medium text-gray-700">Waktu Mulai</label>
                                <input type="time" name="schedules[<?php echo e($index); ?>][start_time]" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500" value="<?php echo e(old('schedules.' . $index . '.start_time', $schedule->start_time?->format('H:i'))); ?>">
                                <?php $__errorArgs = ['schedules.' . $index . '.start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="w-full md:w-1/4">
                                <label class="block text-sm font-medium text-gray-700">Waktu Selesai</label>
                                <input type="time" name="schedules[<?php echo e($index); ?>][end_time]" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500" value="<?php echo e(old('schedules.' . $index . '.end_time', $schedule->end_time?->format('H:i'))); ?>">
                                <?php $__errorArgs = ['schedules.' . $index . '.end_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="w-full md:w-1/4">
                                <label class="block text-sm font-medium text-gray-700">Lokasi (Opsional)</label>
                                <input type="text" name="schedules[<?php echo e($index); ?>][location]" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500" value="<?php echo e(old('schedules.' . $index . '.location', $schedule->location)); ?>">
                                <?php $__errorArgs = ['schedules.' . $index . '.location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <button type="button" onclick="removeScheduleField(this, <?php echo e($schedule->id); ?>)" class="px-3 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 text-sm font-semibold flex-shrink-0">Hapus</button>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
                <button type="button" id="add-schedule-field" class="mt-4 px-4 py-2 bg-teal-500 text-white rounded-md hover:bg-teal-600 text-sm font-semibold">Tambah Jadwal Lain</button>

                <div class="flex items-center justify-end mt-6">
                    <a href="<?php echo e(route('admin.halaqohs.index')); ?>" class="inline-flex items-center px-6 py-3 bg-gray-200 border border-transparent rounded-full font-semibold text-xs text-gray-700 uppercase tracking-widest hover:bg-gray-300 focus:bg-gray-300 active:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300 focus:ring-offset-2 transition ease-in-out duration-150 shadow-sm mr-2">
                        Batal
                    </a>
                    <button type="submit" class="inline-flex items-center px-6 py-3 bg-teal-700 border border-transparent rounded-full font-semibold text-white uppercase tracking-widest hover:bg-teal-800 focus:bg-teal-800 active:bg-teal-900 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2 transition ease-in-out duration-150 shadow-lg">
                        Simpan Perubahan Halaqoh
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    
    <link href="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/css/tom-select.css" rel="stylesheet">
    
    <script src="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/js/tom-select.complete.min.js"></script>
    <script>
        let scheduleIndex = <?php echo e($halaqoh->schedules->count() > 0 ? $halaqoh->schedules->count() : 0); ?>; // Mulai indeks dari jumlah jadwal yang sudah ada

        document.getElementById('add-schedule-field').addEventListener('click', function() {
            const container = document.getElementById('schedules-container');
            const newItem = document.createElement('div');
            newItem.className = 'flex flex-col md:flex-row items-end space-y-2 md:space-y-0 md:space-x-2 schedule-item new-schedule-item';
            newItem.innerHTML = `
                <div class="w-full md:w-1/4">
                    <label class="block text-sm font-medium text-gray-700">Hari</label>
                    <select name="schedules[${scheduleIndex}][day_of_week]" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500">
                        <option value="">Pilih Hari</option>
                        <?php $__currentLoopData = $daysOfWeek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($day); ?>"><?php echo e($day); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="w-full md:w-1/4">
                    <label class="block text-sm font-medium text-gray-700">Waktu Mulai</label>
                    <input type="time" name="schedules[${scheduleIndex}][start_time]" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500">
                </div>
                <div class="w-full md:w-1/4">
                    <label class="block text-sm font-medium text-gray-700">Waktu Selesai</label>
                    <input type="time" name="schedules[${scheduleIndex}][end_time]" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500">
                </div>
                <div class="w-full md:w-1/4">
                    <label class="block text-sm font-medium text-gray-700">Lokasi (Opsional)</label>
                    <input type="text" name="schedules[${scheduleIndex}][location]" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500">
                </div>
                <button type="button" onclick="removeScheduleField(this)" class="px-3 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 text-sm font-semibold flex-shrink-0">Hapus</button>
            `;
            container.appendChild(newItem);
            scheduleIndex++;
        });

        function removeScheduleField(button, scheduleId = null) {
            if (scheduleId) {
                if (confirm('Menghapus jadwal yang sudah ada akan menghapusnya secara permanen dari database. Lanjutkan?')) {
                    fetch(`/admin/halaqohs/schedules/${scheduleId}`, {
                        method: 'DELETE',
                        headers: {
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                            'Content-Type': 'application/json'
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.message) {
                            alert(data.message);
                            button.closest('.schedule-item').remove();
                        } else {
                            alert('Gagal menghapus jadwal.');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Terjadi kesalahan saat menghapus jadwal.');
                    });
                }
            } else {
                button.closest('.schedule-item').remove();
            }
        }

        // Inisialisasi Tom Select pada dropdown santri
        document.addEventListener('DOMContentLoaded', function() {
            const studentLimit = parseInt(document.getElementById('student_limit').value); // Ambil batas santri
            new TomSelect("#selected_students",{
                plugins: ['remove_button'], // Tambahkan plugin untuk tombol hapus pada item yang dipilih
                persist: false,
                create: false, // Jangan izinkan membuat opsi baru
                sortField: {
                    field: "text",
                    direction: "asc"
                },
                placeholder: 'Cari dan pilih santri...',
                maxItems: studentLimit > 0 ? studentLimit : null, // Terapkan batas santri
                // Kustomisasi render untuk menampilkan tipe santri
                itemRenderer: function(data, escape) {
                    return '<div>' + escape(data.text) + ' <span class="text-gray-400 text-xs">(' + escape(data.data.type) + ')</span></div>';
                },
                optionRenderer: function(data, escape) {
                    return '<div>' + escape(data.text) + ' <span class="text-gray-400 text-xs">(' + escape(data.data.type) + ')</span></div>';
                },
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/husnulfuadifebriansyah/Documents/project/ponpesdibama/resources/views/admin/halaqohs/edit.blade.php ENDPATH**/ ?>