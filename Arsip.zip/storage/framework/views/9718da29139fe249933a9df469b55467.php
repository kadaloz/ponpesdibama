<?php $__env->startSection('title', 'Edit Izin Peran: ' . ucfirst($role->name)); ?>

<?php $__env->startSection('header_admin', 'Edit Izin untuk Peran ' . ucfirst($role->name)); ?>

<?php $__env->startSection('admin_content'); ?>
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 text-gray-900">
            <h3 class="text-2xl font-bold text-teal-700 mb-6">Kelola Izin untuk Peran: <span class="text-indigo-700"><?php echo e(ucfirst($role->name)); ?></span></h3>

            <?php if(session('success')): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg relative mb-4 shadow-sm" role="alert">
                    <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg relative mb-4 shadow-sm" role="alert">
                    <span class="block sm:inline"><?php echo e(session('error')); ?></span>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('admin.permissions.update', $role->id)); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <?php if($role->name === 'admin'): ?>
                    <div class="bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded-lg relative mb-4" role="alert">
                        <span class="block sm:inline">Peran 'admin' secara otomatis memiliki semua izin. Tidak dapat diubah secara manual.</span>
                    </div>
                <?php endif; ?>

                <div class="space-y-8"> 
                    <?php $__currentLoopData = $categorizedPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryName => $permissionsInGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!empty($permissionsInGroup)): ?> 
                            <div class="border border-gray-200 rounded-lg p-5 shadow-sm bg-gray-50">
                                <h4 class="text-xl font-bold text-gray-800 mb-4 pb-2 border-b border-gray-200"><?php echo e($categoryName); ?></h4>
                                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"> 
                                    <?php $__currentLoopData = $permissionsInGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="flex items-center">
                                            <input type="checkbox" name="permissions[]" id="permission_<?php echo e($permission->id); ?>" value="<?php echo e($permission->id); ?>"
                                                   class="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
                                                   <?php echo e(in_array($permission->id, old('permissions', $rolePermissions)) ? 'checked' : ''); ?>

                                                   <?php echo e($role->name === 'admin' ? 'disabled' : ''); ?>>
                                            <label for="permission_<?php echo e($permission->id); ?>" class="ml-2 block text-sm text-gray-900">
                                                <?php echo e(ucfirst(str_replace('_', ' ', $permission->name))); ?>

                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
                <?php $__errorArgs = ['permissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1 col-span-full"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['permissions.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1 col-span-full"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="flex items-center justify-end mt-6">
                    <a href="<?php echo e(route('admin.permissions.index')); ?>" class="inline-flex items-center px-6 py-3 bg-gray-200 border border-transparent rounded-full font-semibold text-xs text-gray-700 uppercase tracking-widest hover:bg-gray-300 focus:bg-gray-300 active:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300 focus:ring-offset-2 transition ease-in-out duration-150 shadow-sm mr-2">
                        Batal
                    </a>
                    <button type="submit" class="inline-flex items-center px-6 py-3 bg-teal-700 border border-transparent rounded-full font-semibold text-white uppercase tracking-widest hover:bg-teal-800 focus:bg-teal-800 active:bg-teal-900 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2 transition ease-in-out duration-150 shadow-lg"
                            <?php echo e($role->name === 'admin' ? 'disabled' : ''); ?>>
                        Simpan Izin
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/husnulfuadifebriansyah/Documents/project/ponpesdibama/resources/views/admin/permissions/edit.blade.php ENDPATH**/ ?>